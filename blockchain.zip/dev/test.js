
const Blockchain = require('./blockchain');

const bitcoin = new Blockchain();

//bitcoin.createNewBlock(456484,'ASDIWEFNEWRW#@$!@~!@','ASPFOWENFQWENK@I#RQ#');
//bitcoin.createNewTransaction(100,'Nalini','K');
//bitcoin.createNewBlock(654891,'956TEAOPMa','48TEPMASD');
//bitcoin.createNewBlock(1524,'rez','8545');
//bitcoin.createNewBlock(78424185,'_PSOPRM#W$#%','TMPADMWEA!@#$!@156');
//bitcoin.createNewBlock(487461,'APEJN@#$#$^','4612ASDFAWEF');


const previousHash = "tempasodfawe324";

const currentData = [
	{
		amount : 100,
		sender : 'Nalini',
		recepient : 'K'
	},
	{
		amount : 200,
		sender : 'Vishal',
		recepient : 'Y'
	}
]
const nonce = 255;

console.log(bitcoin.hashBlock(previousHash,currentData,nonce));