
Users = function(){
	this.UserList = [];
}

Users.prototype.addNewUser = function(name,emailId, password) {
	const newUser = {
		id : this.UserList.length+1,
		name : name,
		balance : 4000,
		lockedBalance : 0,
		emailId : emailId,
		password : password
	}
	return newUser;
};

Users.prototype.addUserToList = function(userObj){
	this.UserList.push(userObj);
}

Users.prototype.checkUserAlreadyPresent = function(userObj){
	let result = false;
	this.UserList.forEach(element => {
		if(element.emailId == userObj.emailId){
			result = true;
		}
		else
			result = false;
	});
	return result;
}

Users.prototype.findUserInfo = function(emailID, password){
	let userObj = undefined;
	this.UserList.forEach(element => {
		if(element.emailId == emailID && element.password == password){
			userObj = element;
		}
	});
	console.log(userObj);
	return userObj;
}

module.exports = Users;