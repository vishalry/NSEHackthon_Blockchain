const express = require('express');
const app = new express();
const bodyParser = require('body-parser');
const Blockchain = require('./blockchain');
const bitcoin = new Blockchain();
const Users = require('./users');
const Market = require('./market');
const Orders = require('./orders');
const Clients = require('./clients');
const marketObj = new Market();
const user = new Users();
const order = new Orders();
const client = new Clients();
const uuid = require('uuid/v1');
const nodeAddress = uuid().split('-').join('');
const port = process.argv[2];
const rp = require('request-promise');

const firebase = require("firebase");

var firebaseConfig = {
	apiKey: "AIzaSyB56S8d2863R8_NUcD_VKujNTiZHvY1B2g",
    authDomain: "blockchain-ec748.firebaseapp.com",
    databaseURL: "https://blockchain-ec748.firebaseio.com",
    projectId: "blockchain-ec748",
    storageBucket: "blockchain-ec748.appspot.com",
    messagingSenderId: "525015321320"
};
firebase.initializeApp(firebaseConfig);

var path =require('path');
app.use(express.static('public'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended : false}));



app.get('/network-register',function(req,res){
	res.sendFile(path.join(__dirname + req.url+ '/RegisterNetwork.html'));
})

app.get('/user/order-book',function(req,res){
	res.sendFile(path.join(__dirname + '/order-book/orderbook.html'));
})

app.post('/clients/get',function(req,res){
	let cList = client.getClients(req.body.userId);
	res.json(cList);
});

app.post('/market/market-watch',function(req,res){
	res.json(marketObj.ScripList);
});


app.get('/user/home',function(req,res){
	res.sendFile(path.join(__dirname + '/home/Home.html'));
});

app.post('/orders/order-list',function(req,res){
	let userId = req.body.userId;
	let OrdList = [];
	let orderList = order.getOrderUserWise(userId);
	orderList.forEach(function(obj){
		let scripInfo = marketObj.getScripInfo(obj.token);
		let OrdObj = {
			orderNo : obj.orderNo,
			orderType : (obj.type.toLowerCase()=='b'?'Buy Order':'Sell Order'),
			symbol : scripInfo.symbol,
			buyQty : (obj.type.toLowerCase()=='b'?obj.qty:'-'),
			buyAvgPrice : (obj.type.toLowerCase()=='b'?'₹ '+obj.price:'-'),
			buyPaidAmount : (obj.type.toLowerCase()=='b'?'₹ '+(obj.qty*obj.price):'-'),
			sellQty : (obj.type.toLowerCase()=='s'?obj.qty:'-'),
			sellAvgPrice :(obj.type.toLowerCase()=='s'?'₹ '+obj.price:'-'),
			sellPaidAmount : (obj.type.toLowerCase()=='s'?'₹ '+(obj.qty*obj.price):'-'),
		}
		OrdList.push(OrdObj);
	});
	res.json(OrdList);
})

app.post('/orders/broadcast',function(req,res){
	let newOrder = req.body.orderObj;
	if(!order.checkAlreadyPresent(newOrder))
		order.addOrderToList(newOrder);
});

app.post('/orders/place',function(req,res){
	let newOrder = order.placeOrder(req.body.token,req.body.qty,req.body.price,req.body.clientId,req.body.type, req.body.userId);
	if(!order.checkAlreadyPresent(newOrder))
		order.addOrderToList(newOrder);
	const requestPromises = [];
	bitcoin.networkNodes.forEach(networkNodeUrl =>{
		const requestOptions = {
			uri : networkNodeUrl + '/orders/broadcast',
			method : 'POST',
			body : {orderObj : newOrder},
			json : true
		};
		requestPromises.push(rp(requestOptions));
	});
	Promise.all(requestPromises)
		.then(data => {
			console.log(req.url);
	});
	let currentNodedUrl = process.argv[3];
	let requestTransPromises = [];
	const requestTransOptions = {
		uri : currentNodedUrl + '/transaction/broadcast',
		method : 'POST',
		body : {newTransaction : newOrder},
		json : true
	};
	requestTransPromises.push(rp(requestTransOptions));
	Promise.all(requestTransPromises)
		.then(data => {
	});
	// console.log(req.url);
	// let currentNodedUrl = req.protocol+':\\'
    // console.log(req.get('host'));
	// console.log(req.originalUrl);
	
	let scripInfo = marketObj.getScripInfo(newOrder.token);
	let clientObj = client.getClientUsingID(newOrder.clientId);
	if(scripInfo != undefined)
	res.json({message : newOrder.qty+' '+scripInfo.symbol+' Order placed..'});
});

app.get('/user-register',function(req,res){
	res.sendFile(path.join(__dirname + req.url + '/Register.html'));
});

app.post('/users/add',function(req,res){
	// const userObj = {Name : req.body.name,Email : req.body.emailId,Password :req.body.password,
	// 	Balance : 4000, LockedBalance : 0
	// }
	// firebase.database().ref('Users/').push({
	// 	User : userObj
	// });
	let userObj = user.addNewUser(req.body.name,req.body.emailId,req.body.password);
	let result = user.checkUserAlreadyPresent(userObj)
	if(result){
		res.json({error : 'A user already registered with this email id.'});
	}
	else{
		user.addUserToList(userObj);
	}
	const requestPromises = [];
	bitcoin.networkNodes.forEach(networkNodeUrl =>{
		const requestOptions = {
			uri : networkNodeUrl + '/users/broadcast',
			method : 'POST',
			body : {userObj : userObj},
			json : true
		};
		requestPromises.push(rp(requestOptions));
	});
	Promise.all(requestPromises)
	.then(data => {
		//res.json({note : 'User added and broadcast successfully.'});
	});
	res.json({message : userObj.name + ' user added sucessfully.'});
});

app.post('/users/broadcast',function(req,res){
	const userObj = req.body.userObj;
	const result = user.checkUserAlreadyPresent(userObj)
	if(!result)
		user.addUserToList(userObj);
});

app.get('/Users',function(req,res){

	// firebase.database().ref('Users/').on("value", function(snapshot) {
	// 	snapshot.forEach(function(item){
	// 		console.log(item.val());
	// 	});
	//   }, function (errorObject) {
	// 	console.log("The read failed: " + errorObject.code);
	//   });

	res.json(user.UserList);
});


app.get('/login',function(req,res){
//	var path=req.protocol+ '://'+ req.get('host') + req.originalUrl;
	res.sendFile(path.join(__dirname + req.url + '/Login.html'));
});

app.post('/login/success',function(req,res){
	const Email = req.body.emailId;
	const Password = req.body.password;
	let userObj = user.findUserInfo(Email,Password);
	if(userObj != undefined){
		res.json(userObj.id);
	}
	else{
		res.json({Error : 'Invalid Creadentials.'});
	}
//	var path=req.protocol+ '://'+ req.get('host') + req.originalUrl;
	//res.sendFile(path.join(__dirname + req.url + '.html'));
});


app.get('/validateLogin',function(req,res){
	res.send('Validated');
});
	






app.get('/blockchain',function (req,res) {
	res.send(bitcoin);
});

app.post('/transaction',function (req,res) {
	console.log('transaction'+req.url);
	//const blockIndex = bitcoin.createNewTransaction(req.body.amount,req.body.sender,req.body.recepient);
	const newTransaction = req.body.transaction;
	const blockIndex = bitcoin.addTransactionToPendingTransactions(newTransaction);
	res.json({ note : 'Transaction will be added in block '+blockIndex});
});

app.post('/transaction/broadcast',function(req,res){
	const newTransaction = req.body.newTransaction;// bitcoin.createNewTransaction(req.body.amount,req.body.sender,req.body.recepient);
	console.log('transaction broadcast'+req.url);
	bitcoin.addTransactionToPendingTransactions(newTransaction);

	const requestPromises = [];
	bitcoin.networkNodes.forEach(networkNodeUrl =>{
		const requestOptions = {
			uri : networkNodeUrl + '/transaction',
			method : 'POST',
			body : {transaction : newTransaction},
			json : true
		};
		requestPromises.push(rp(requestOptions));
	});
	Promise.all(requestPromises)
	.then(data => {
		res.json({note : 'Transaction created and broadcast successfully.'});
	});

});

app.post('/receive-new-block',function(req, res){
	let newBlock = req.body.newBlock;
	let lastBlock = bitcoin.getLastBlock();
	let correctHash = true;
	let correctIndex = true;
	if(bitcoin.chain.length>1){
		correctHash = lastBlock.hash === newBlock.hash;
		correctIndex = lastBlock.index+1 === newBlock.index;	
	}
	if(correctHash && correctIndex){
		bitcoin.chain.push(newBlock);
		bitcoin.pendingTransactions = [];
		res.send({
			note : 'New block recevied and accepted.',
			newBlock : newBlock
		});
	}
	else{
		res.send({
			note : 'New block rejected.',
			newBlock : newBlock
		});
	}
});

app.get('/mine',function (req,res) {
	let lastBlock = bitcoin.getLastBlock();
	let previousBlockHash = lastBlock['hash'];
	let currentBlockData = {
		transaction : bitcoin.pendingTransactions,
		index : lastBlock['index'] + 1
	};
	let nonce = bitcoin.proofOfWork(previousBlockHash,currentBlockData);
	let blockHash = bitcoin.hashBlock(previousBlockHash,currentBlockData,nonce);
	//bitcoin.createNewTransaction(12.5,"00",nodeAddress);
	let newBlock = bitcoin.createNewBlock(nonce,previousBlockHash,blockHash);

	let requestPromises = [];
	bitcoin.networkNodes.forEach(networkNodeUrl =>{
		let requestOptions = {
			uri : networkNodeUrl + '/receive-new-block',
			method : 'POST',
			body : { newBlock : newBlock},
			json : true
		};
		requestPromises.push(rp(requestOptions));
	});
	Promise.all(requestPromises)
	.then(data=>{
		// const requestOptions = {
		// 	uri : bitcoin.currentNodeUrl + '/transaction/broadcast',
		// 	method : 'POST',
		// 	body : {
		// 		amount : 12.5,
		// 		sender : "00",
		// 		recepient : nodeAddress
		// 	},
		// 	json : true
		// };
		// return rp(requestOptions);
		res.json({
			note : "New block mined successfully",
			block : newBlock
		});
	});
	// .then(data =>{
	// 	res.json({
	// 		note : "New block mined successfully",
	// 		block : newBlock
	// 	});
	// });
});

app.post('/register-and-broadcast-node', function(req,res){
	const newNodeUrl = req.body.newNodeUrl;
	if(bitcoin.networkNodes.indexOf(newNodeUrl)==-1)
		bitcoin.networkNodes.push(newNodeUrl);
	const regNodesPromises = [];
	bitcoin.networkNodes.forEach(networkNodeUrl => {
		const requestOptions = {
			uri : networkNodeUrl+'/register-node',
			method : 'POST',
			body : { "newNodeUrl" : newNodeUrl},
			json : true
		};
		regNodesPromises.push(rp(requestOptions));
	});

	Promise.all(regNodesPromises)
	.then(data => {
		const bulkRegisterOptions = {
			uri : newNodeUrl + '/register-nodes-bulk',
			method : 'POST',
			body : { "allNetworkNodes" : [...bitcoin.networkNodes, bitcoin.currentNodeUrl]},
			json : true
		};
		return rp(bulkRegisterOptions);
	})
	.then(data =>{
		res.json({message : newNodeUrl+' node registered with network successfully'});
	});
});


app.post('/register-node',function(req,res){
	const newNodeUrl = req.body.newNodeUrl;
	const nodeNotAlreadyPresent = bitcoin.networkNodes.indexOf(newNodeUrl) == -1;
	const notCurrentNode = bitcoin.currentNodeUrl != newNodeUrl;
	if(nodeNotAlreadyPresent && notCurrentNode)
		bitcoin.networkNodes.push(newNodeUrl);
	res.json({ note : 'New node registered successfully with node.'});
});

app.post('/register-nodes-bulk',function(req,res){
	const allNetworkNodes = req.body.allNetworkNodes;

	allNetworkNodes.forEach(networkNodeUrl => {
		const nodeNotAlreadyPresent = bitcoin.networkNodes.indexOf(networkNodeUrl) == -1;
		const notCurrentNode = bitcoin.currentNodeUrl != networkNodeUrl;
		if(nodeNotAlreadyPresent && notCurrentNode)
			bitcoin.networkNodes.push(networkNodeUrl);	
		});
	
	res.json({ note : 'Bulk Registration successful.'});
});


app.listen(port, function(){
	console.log('Server listening on '+port+' port...');
});