
const Orders = function(){
    this.orderList = [];
}

Orders.prototype.placeOrder = function(token,qty,price,clientId,type,userId){
    const newOrder = {
        orderNo : this.orderList.length+1,
        type : type,
        token : token,
        qty : qty,
        price : price,
        clientId : clientId,
        userId : userId
    }
    return newOrder;
}

Orders.prototype.addOrderToList = function(orderObj){
    this.orderList.push(orderObj);
}

Orders.prototype.checkAlreadyPresent = function(orderObj){
    let result = false;
    this.orderList.forEach(function(element){
        if(element.orderNo == orderObj.orderNo)
            result = true;
        else
            result = false;
    });
    return result;
}

Orders.prototype.getOrderUserWise = function(userId){
    let ordList = [];
    this.orderList.forEach(function(element){
        if(element.userId == userId)
            ordList.push(element);
    });
    return ordList;
}


module.exports = Orders;
