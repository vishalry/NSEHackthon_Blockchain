
const Clients = function(){
    this.ClientList = [];
    this.ClientList = [
        {clientId : this.ClientList.length+1, name : 'C1', userId : 1},
        {clientId : this.ClientList.length+1, name : 'C2', userId : 1},
        {clientId : this.ClientList.length+1, name : 'C3', userId : 2},
        {clientId : this.ClientList.length+1, name : 'C4', userId : 2},
        {clientId : this.ClientList.length+1, name : 'C5', userId : 3},
        {clientId : this.ClientList.length+1, name : 'C6', userId : 3},
        {clientId : this.ClientList.length+1, name : 'C7', userId : 4},
        {clientId : this.ClientList.length+1, name : 'C8', userId : 4},
        {clientId : this.ClientList.length+1, name : 'C9', userId : 5},
        {clientId : this.ClientList.length+1, name : 'C10', userId : 5}
    ]
}

Clients.prototype.getClients= function(userId){
    let clist = [];
    this.ClientList.forEach(clObj =>{
        if(clObj.userId == userId)
        clist.push(clObj);
    });
    return clist;
}

Clients.prototype.getClientUsingID= function(clientId){
    let cInfo = undefined;
    this.ClientList.forEach(clObj =>{
        if(clObj.clientId == clientId)
        cInfo = clObj;
    });
    return cInfo;
}


Clients.prototype.addClient = function(clientObj){
    if(!this.checkClientAlreadyPresent(clientObj))
        this.ClientList.add(clientObj);
}

Clients.prototype.checkClientAlreadyPresent = function(clientObj){
    let result = false;
    this.ClientList.forEach((element)=>{
        if(element.clientId == clientObj.clientId)
            result = true;
        else
        result = false;
    });
    return result;
}


module.exports = Clients;