
const Market = function(){
    this.ScripList = [
        {symbol : 'Reliance',token : 926327,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 1235.90,ltQty : 100,ltdTime : Date.now()
        },
        {symbol : 'Cipla',token : 926637,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 600.30,ltQty : 60,ltdTime : Date.now()
        },
        {symbol : 'TCS',token : 903637,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 2490,ltQty : 20,ltdTime : Date.now()
        },
        {symbol : 'TechMah',token : 324637,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 960.75,ltQty : 10,ltdTime : Date.now()
        },
        {symbol : 'HDFC',token : 926322,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 1560,ltQty : 80,ltdTime : Date.now()
        },
        {symbol : 'Britania',token : 924353,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 254.86,ltQty : 45,ltdTime : Date.now()
        },
        {symbol : 'Kotak',token : 924325,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 120.45,ltQty : 38,ltdTime : Date.now()
        },
        {symbol : 'Infy',token : 922345,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 380,ltQty : 100,ltdTime : Date.now()
        },
        {symbol : 'Suzlon',token : 926323,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 679.36,ltQty : 75,ltdTime : Date.now()
        },
        {symbol : 'Eclerx',token : 922341,segment : 'NSECM',
            bbQty : 20,bsQty : 30,bbPrice : 1210.50,bsPrice : 1240.34,
            ltPrice : 1230.95,ltQty : 5,ltdTime : Date.now()
        }
        
    ]
}

Market.prototype.addScrip = function(scripObj){
    if(!this.checkScripAlreadyPresent(scripObj))
        this.ScripList.add(scripObj);
}

Market.prototype.checkScripAlreadyPresent = function(scripObj){
    let result = false;
    this.ScripList.forEach((element)=>{
        if(element.symbol == scripObj.symbol
        && element.token == scripObj.token)
            result = true;
        else
        result = false;
    });
    return result;
}

Market.prototype.getScripInfo = function(token){
    let scripInfo = undefined;
    this.ScripList.forEach((element)=>{
        if(element.token == token)
        scripInfo = element;
    });
    return scripInfo;
}


module.exports = Market;