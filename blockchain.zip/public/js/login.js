var attempt = 3; //Variable to count number of attempts
//Below function Executes on click of login button
function validateLogin()
{
	var username = document.getElementById("username").value;
	var password = document.getElementById("password").value;

	$.ajax({
        url: '/login/success',
        type: 'POST',
        data: JSON.stringify({emailId: username, password : password}) ,
        contentType: 'application/json; charset=utf-8',
        success: function (response) {
			window.location = "/user/home?userId="+response;
        },
        error: function (error) {
			alert(error);
            console.log(error);
        }
    }); 
}


function registerValidate()
{
	var username = document.getElementById("username").value;
	var password = document.getElementById("password").value;
	var email = document.getElementById("email").value;

	if ( username == "" || password == "" || email=="")
	{
		alert ("Please enter all the details");
	}
	else
	{
		
	$.ajax({
        url: '/users/add',
        type: 'POST',
        data: JSON.stringify({name: username, emailId:email, password : password}) ,
        contentType: 'application/json; charset=utf-8',
        success: function (response) {
			if(response.error)
				alert(response.error)
			else
            	alert(response.message);
        },
        error: function (error) {
            console.log(error);
        }
    }); 
		window.location = "/login"; //redirecting to other page
		return false;
	}
}